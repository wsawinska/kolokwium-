import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {
    // metoda startowa aplikacji
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("Spadające kwadraty");
                // panel gry
                GamePanel panel = new GamePanel(5, 10, 30);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.getContentPane().add(panel);
                frame.pack();
                frame.setResizable(false);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                panel.requestFocusInWindow();
            }
        });
    }
}

// panel gry
class GamePanel extends JPanel implements KeyListener {
    private final int cols;            // l kolumn
    private final int rows;            // l wierszy
    private final int unit;            // rozmiar
    private final boolean[][] grid;    // siataka zaj komorek
    private ActiveSquare active;       // spadający kwadrat
    private final Object lock = new Object(); // blokada synch
    private int score = 0;             // wynik

    // plansza i timer startowu
    public GamePanel(int cols, int rows, int unit) {
        this.cols = cols;
        this.rows = rows;
        this.unit = unit;
        this.grid = new boolean[rows][cols];
        setPreferredSize(new Dimension(cols * unit, rows * unit));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);

        // timer na pierwxz kwadrat
        Timer t = new Timer(200, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Timer) e.getSource()).stop();
                spawnNewSquare();
            }
        });
        t.setRepeats(false);
        t.start();
    }

    // nowy kw na srd planszy
    private void spawnNewSquare() {
        synchronized (lock) {
            int startCol = cols / 2;
            ActiveSquare s = new ActiveSquare(startCol, 0, Color.BLUE);
            active = s;
            // swoj watek dla kazdego kw
            Thread th = new Thread(s);
            th.start();
        }
    }

    // rys planszu i akt kwadratu
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // siatka i zaj komrokwi
        synchronized (lock) {
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (grid[r][c]) {
                        g.setColor(Color.GRAY);
                        g.fillRect(c * unit, r * unit, unit, unit);
                        g.setColor(Color.BLACK);
                        g.drawRect(c * unit, r * unit, unit, unit);
                    } else {
                        g.setColor(Color.DARK_GRAY);
                        g.drawRect(c * unit, r * unit, unit, unit);
                    }
                }
            }
            // rys akt kwadratu
            if (active != null) {
                g.setColor(active.color);
                g.fillRect(active.col * unit, active.row * unit, unit, unit);
                g.setColor(Color.BLACK);
                g.drawRect(active.col * unit, active.row * unit, unit, unit);
            }
        }
        // wynik
        g.setColor(Color.WHITE);
        g.drawString("Wynik: " + score, 5, 12);
    }

    // spr czy komorka jest zaj
    private boolean isOccupied(int r, int c) {
        if (r < 0 || r >= rows || c < 0 || c >= cols) return true;
        return grid[r][c];
    }

    // umieszczenia kwadratu na planszy i spr czy trzeba wyczyścić wiersz
    private void settleSquare(ActiveSquare s) {
        synchronized (lock) {
            if (s.row >= 0 && s.row < rows && s.col >= 0 && s.col < cols) {
                grid[s.row][s.col] = true;
            }
            active = null;
            clearFullRows();
        }
        // nowy kwadrat po czasies
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Timer t = new Timer(100, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        ((Timer) e.getSource()).stop();
                        spawnNewSquare();
                    }
                });
                t.setRepeats(false);
                t.start();
            }
        });
    }

    // usuwanie pelnych wierszy i spadanie reszty
    private void clearFullRows() {
        int cleared = 0;
        for (int r = rows - 1; r >= 0; r--) {
            boolean full = true;
            for (int c = 0; c < cols; c++) {
                if (!grid[r][c]) { full = false; break; }
            }
            if (full) {
                // wszystko powyżej o 1 w dół
                for (int rr = r; rr > 0; rr--) {
                    System.arraycopy(grid[rr - 1], 0, grid[rr], 0, cols);
                }
                // pierwzy wiersz zero
                for (int c = 0; c < cols; c++) grid[0][c] = false;
                cleared++;
                r++; // spr wiersza ponownie
            }
        }
        if (cleared > 0) {
            score += cleared * 100;
            repaint();
        }
    }

    // ruch klawiszy prawo lewo
    public void keyTyped(KeyEvent e) { }
    public void keyReleased(KeyEvent e) { }

    public void keyPressed(KeyEvent e) {
        boolean repaintNeeded = false;
        synchronized (lock) {
            if (active != null) {
                int code = e.getKeyCode();
                if (code == KeyEvent.VK_LEFT) {
                    // ruch lewo jak moze
                    if (active.col > 0 && !grid[active.row][active.col - 1]) { active.col--; repaintNeeded = true; }
                } else if (code == KeyEvent.VK_RIGHT) {
                    // ruch w prawo jak moze
                    if (active.col < cols - 1 && !grid[active.row][active.col + 1]) { active.col++; repaintNeeded = true; }
                } else if (code == KeyEvent.VK_DOWN) {
                    // od razu w dol jak moze
                    if (active.row < rows - 1 && !grid[active.row + 1][active.col]) { active.row++; repaintNeeded = true; }
                }
            }
        }
        if (repaintNeeded) repaint();
    }

    // spadajacy kwadrat
    private class ActiveSquare implements Runnable {
        volatile int col; // kolumna
        volatile int row; // wiersz
        final Color color; // kolor kwadratu
        private final int fallDelay = 100; // opóźnienie opadania

        ActiveSquare(int col, int row, Color color) {
            this.col = col;
            this.row = row;
            this.color = color;
        }

        // logika spadania kwadratu
        public void run() {
            try {
                synchronized (lock) {
                    if (isOccupied(row, col)) {
                        // jesli start na zaj komrorce koniec gry
                        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) grid[r][c] = false;
                        score = 0;
                        SwingUtilities.invokeLater(new Runnable() { public void run() { repaint(); } });
                        settleSquare(this);
                        return;
                    }
                }

                while (true) {
                    Thread.sleep(fallDelay);
                    boolean shouldSettle = false;
                    synchronized (lock) {
                        if (row + 1 >= rows || grid[row + 1][col]) {
                            // przeskoda zostawienie kwadartu
                            shouldSettle = true;
                        } else {
                            // mozna opuszczac dalj
                            row++;
                        }
                    }
                    SwingUtilities.invokeLater(new Runnable() { public void run() { repaint(); } });
                    if (shouldSettle) {
                        settleSquare(this);
                        break;
                    }
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
